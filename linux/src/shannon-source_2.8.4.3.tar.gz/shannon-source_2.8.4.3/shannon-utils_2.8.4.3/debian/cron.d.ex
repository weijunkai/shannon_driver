#
# Regular cron jobs for the shannon-utils package
#
0 4	* * *	root	[ -x /usr/bin/shannon-utils_maintenance ] && /usr/bin/shannon-utils_maintenance
