?package(shannon-utils):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="shannon-utils" command="/usr/bin/shannon-utils"
