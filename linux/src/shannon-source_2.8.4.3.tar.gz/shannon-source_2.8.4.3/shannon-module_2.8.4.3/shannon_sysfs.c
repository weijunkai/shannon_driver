#include "shannon_pci.h"
#include "shannon_sysfs.h"
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <linux/errno.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/genhd.h>
#include <linux/pci.h>
#include <linux/hwmon.h>
#include <linux/hwmon-sysfs.h>
#include "shannon_scsi.h"

struct shannon_attr {
	struct attribute attr;
	shannon_ssize_t (*show)(struct shannon_dev *, char *);
	shannon_ssize_t (*store)(struct shannon_dev *, const char *, shannon_size_t count);
};

struct shannon_device_attr {
	struct device_attribute attr;
	shannon_ssize_t (*show)(struct shannon_dev *, char *);
	shannon_ssize_t (*store)(struct shannon_dev *, const char *, shannon_size_t count);
};

#define define_one_rw(_name) \
static struct shannon_attr _name = \
__ATTR(_name, 0644, _name##_show, _name##_store)

#define define_one_ro(_name) \
static struct shannon_attr _name = \
__ATTR_RO(_name)

#define define_one_device_rw(_name) \
static struct shannon_device_attr _name = {\
	.attr = __ATTR(_name, 0644, shannon_device_show, shannon_device_store), \
	.show = _name##_show,\
	.store = _name##_store,\
}

#define define_one_device_ro(_name) \
static struct shannon_device_attr _name = {\
	.attr = __ATTR(_name, 0644, shannon_device_show, shannon_device_store), \
	.show = _name##_show,\
}

#define to_shannon_attr(a) container_of(a, struct shannon_attr, attr)
#define to_shannon_device_attr(a) container_of(a, struct shannon_device_attr, attr)

extern int shannon_scsi_mode;
static shannon_ssize_t shannon_device_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct pci_dev *pdev = NULL;
	struct shannon_dev *sdev = NULL;
	struct shannon_device_attr *sattr = NULL;
	shannon_ssize_t ret = -EINVAL;
	struct shannon_scsi_private *hostdata;

	pdev = container_of(dev, struct pci_dev, dev);
	if (shannon_scsi_mode) {
		hostdata = shannon_pci_get_drvdata(pdev);
		sdev = hostdata->sdev;
	} else
		sdev = shannon_pci_get_drvdata(pdev);
	sattr = to_shannon_device_attr(attr);

	if (sattr->show)
		ret = sattr->show(sdev, buf);
	else
		ret = -EIO;

	return ret;
}

static ssize_t shannon_device_store(struct device *dev, struct device_attribute *attr, const char *buf, shannon_size_t count)
{
	struct pci_dev *pdev = NULL;
	struct shannon_dev *sdev = NULL;
	struct shannon_device_attr *sattr = NULL;
	shannon_ssize_t ret = -EINVAL;
	struct shannon_scsi_private *hostdata;

	pdev = container_of(dev, struct pci_dev, dev);
	if (shannon_scsi_mode) {
		hostdata = shannon_pci_get_drvdata(pdev);
		sdev = hostdata->sdev;
	} else
		sdev = shannon_pci_get_drvdata(pdev);
	sattr = to_shannon_device_attr(attr);

	if (sattr->store)
		ret = sattr->store(sdev, buf, count);
	else
		ret = -EIO;

	return ret;
}

static shannon_ssize_t shannon_show(struct kobject *kobj, struct attribute *attr, char *buf)
{
	struct shannon_dev *sdev = to_shannon_dev((shannon_kobject_t *)kobj);
	struct shannon_attr *sattr = to_shannon_attr(attr);
	shannon_ssize_t ret = -EINVAL;

	if(sattr->show)
		ret = sattr->show(sdev, buf);
	else
		ret = -EIO;

	return ret;
}

static shannon_ssize_t shannon_store(struct kobject *kobj, struct attribute *attr, const char *buf, shannon_size_t count)
{
	struct shannon_dev *sdev = to_shannon_dev((shannon_kobject_t *)kobj);
	struct shannon_attr *sattr = to_shannon_attr(attr);
	shannon_ssize_t ret = -EINVAL;

	if(sattr->store)
		ret = sattr->store(sdev, buf, count);
	else
		ret = -EIO;

	return ret;
}

static void shannon_sysfs_release(struct kobject *kobj)
{
}

static struct sysfs_ops shannon_sysfs_ops = {
	.show = shannon_show,
	.store = shannon_store,
};

define_one_ro(model);
define_one_ro(firmware_version);
define_one_ro(firmware_build);
define_one_ro(driver_version);
define_one_ro(serial_number);
define_one_ro(configuration);
define_one_ro(block_size);
define_one_ro(use_dual_head);
define_one_ro(pci_info);
define_one_ro(power_on_seconds);
define_one_ro(power_cycle_count);
define_one_ro(user_capacity);
define_one_ro(physical_capacity);
define_one_ro(overprovision);
define_one_ro(free_blkcnt);
define_one_ro(static_bad_blkcnt);
define_one_ro(dynamic_bad_blkcnt);
define_one_ro(reconfig_support);
define_one_ro(seu_flag);
define_one_ro(seu_crc_error);
define_one_ro(seu_crc_error_history);
define_one_ro(seu_ecc_error);
define_one_ro(seu_ecc_error_history);
define_one_ro(estimated_life_left);
define_one_ro(host_write_sectors);
define_one_ro(host_write_bandwidth);
define_one_ro(host_write_iops);
define_one_ro(host_write_latency);
define_one_ro(total_write_sectors);
define_one_ro(total_write_bandwidth);
define_one_ro(write_amplifier);
define_one_ro(write_amplifier_lifetime);
define_one_ro(host_read_sectors);
define_one_ro(host_read_bandwidth);
define_one_ro(host_read_iops);
define_one_ro(host_read_latency);
define_one_ro(temperature_int);
define_one_ro(temperature_int_max);
define_one_ro(temperature_flash);
define_one_ro(temperature_flash_max);
define_one_ro(temperature_board);
define_one_ro(temperature_board_max);
define_one_ro(voltage_int);
define_one_ro(voltage_int_max);
define_one_ro(voltage_aux);
define_one_ro(voltage_aux_max);
define_one_ro(ecc_failure_times);
define_one_ro(ecc_statistics);
define_one_ro(device_state);
define_one_ro(access_mode);
define_one_ro(readonly_reason);
define_one_ro(reduced_write_reason);
define_one_rw(pm_qos_value);
define_one_ro(service_tag);
define_one_ro(fpga_dna);
define_one_ro(udid);
define_one_ro(refresh_mbr_count);
define_one_ro(atomic_write);
define_one_ro(prioritize_write);

#ifdef CONFIG_HWMON
define_one_device_ro(name);
define_one_device_ro(temp1_input);
define_one_device_ro(temp1_label);
define_one_device_ro(temp1_max);
define_one_device_ro(temp1_crit);
define_one_device_ro(temp2_input);
define_one_device_ro(temp2_label);
define_one_device_ro(temp2_max);
define_one_device_ro(temp2_crit);
define_one_device_ro(temp3_input);
define_one_device_ro(temp3_label);
define_one_device_ro(temp3_max);
define_one_device_ro(temp3_crit);

static struct device_attribute *shannon_hwmon_attrs[] = {
	&name.attr,
	&temp1_input.attr,
	&temp1_label.attr,
	&temp1_max.attr,
	&temp1_crit.attr,
	&temp2_input.attr,
	&temp2_label.attr,
	&temp2_max.attr,
	&temp2_crit.attr,
	&temp3_input.attr,
	&temp3_label.attr,
	&temp3_max.attr,
	&temp3_crit.attr,
	NULL,
};
#endif

static struct attribute *shannon_default_attrs[] = {
	&model.attr,
	&firmware_version.attr,
	&firmware_build.attr,
	&driver_version.attr,
	&serial_number.attr,
	&configuration.attr,
	&block_size.attr,
	&use_dual_head.attr,
	&pci_info.attr,
	&power_on_seconds.attr,
	&power_cycle_count.attr,
	&user_capacity.attr,
	&physical_capacity.attr,
	&overprovision.attr,
	&free_blkcnt.attr,
	&static_bad_blkcnt.attr,
	&dynamic_bad_blkcnt.attr,
	&reconfig_support.attr,
	&seu_flag.attr,
	&seu_crc_error.attr,
	&seu_crc_error_history.attr,
	&seu_ecc_error.attr,
	&seu_ecc_error_history.attr,
	&estimated_life_left.attr,
	&host_write_sectors.attr,
	&host_write_bandwidth.attr,
	&host_write_iops.attr,
	&host_write_latency.attr,
	&total_write_sectors.attr,
	&total_write_bandwidth.attr,
	&write_amplifier.attr,
	&write_amplifier_lifetime.attr,
	&host_read_sectors.attr,
	&host_read_bandwidth.attr,
	&host_read_iops.attr,
	&host_read_latency.attr,
	&temperature_int.attr,
	&temperature_int_max.attr,
	&temperature_flash.attr,
	&temperature_flash_max.attr,
	&temperature_board.attr,
	&temperature_board_max.attr,
	&voltage_int.attr,
	&voltage_int_max.attr,
	&voltage_aux.attr,
	&voltage_aux_max.attr,
	&ecc_failure_times.attr,
	&ecc_statistics.attr,
	&device_state.attr,
	&access_mode.attr,
	&readonly_reason.attr,
	&reduced_write_reason.attr,
	&pm_qos_value.attr,
	&service_tag.attr,
	&fpga_dna.attr,
	&udid.attr,
	&refresh_mbr_count.attr,
	&atomic_write.attr,
	&prioritize_write.attr,
	NULL,
};

static struct kobj_type shannon_ktype = {
	.sysfs_ops = &shannon_sysfs_ops,
	.default_attrs = shannon_default_attrs,
	.release = shannon_sysfs_release,
};


int shannon_sysfs_init(shannon_kobject_t *skobj)
{
	struct gendisk *disk = (struct gendisk *)to_shannon_disk(skobj);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
	struct device *ddev = disk_to_dev(disk);
#else
	struct device *ddev = &disk->dev;
#endif
	memset(skobj, 0x00, sizeof(shannon_kobject_t));
	return kobject_init_and_add((struct kobject *)skobj, &shannon_ktype, &ddev->kobj, "shannon");
#else
	struct kobject *kobj = (struct kobject*)skobj;

	memset(skobj, 0x00, sizeof(shannon_kobject_t));
	kobject_init(kobj);
	kobj->parent = &disk->kobj;
	kobject_set_name(kobj, "shannon");
	kobj->ktype = &shannon_ktype;
	return kobject_add(kobj);
#endif
}

void shannon_sysfs_exit(shannon_kobject_t *skobj)
{
	kobject_del((struct kobject *)skobj);
}

shannon_device_t *shannon_hwmon_init(shannon_pci_dev_t *pdev)
{
#ifdef CONFIG_HWMON
	struct device *dev = &((struct pci_dev *)pdev)->dev;
	struct device *hwmon_dev = NULL;

	int err = 0;
	int i;


	for (i = 0; shannon_hwmon_attrs[i] && !err; i++)
		err = device_create_file(dev, shannon_hwmon_attrs[i]);

	if (err) {
		while (--i >= 0)
			device_remove_file(dev, shannon_hwmon_attrs[i]);
		debugs0("create hwmon sysfs files failed!");
		return NULL;
	}

	hwmon_dev = hwmon_device_register(dev);
	if (IS_ERR(hwmon_dev)) {
		debugs0("hwmon_device_register failed!");
		for (i = 0; shannon_hwmon_attrs[i]; i++)
			device_remove_file(dev, shannon_hwmon_attrs[i]);
		return NULL;
	}

	return hwmon_dev;
#else
	return NULL;
#endif
}

void shannon_hwmon_exit(shannon_pci_dev_t *pdev, shannon_device_t *hwmon_dev)
{
#ifdef CONFIG_HWMON
	struct device *dev = &((struct pci_dev *)pdev)->dev;
	int i;

	if (SHANNON_IS_ERR_OR_NULL(hwmon_dev))
		return;

	hwmon_device_unregister((struct device *)hwmon_dev);
	for (i = 0; shannon_hwmon_attrs[i]; i++)
		device_remove_file(dev, shannon_hwmon_attrs[i]);
#endif
}
