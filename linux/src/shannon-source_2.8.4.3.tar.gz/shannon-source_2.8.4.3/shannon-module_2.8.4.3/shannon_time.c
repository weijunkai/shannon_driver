#include "shannon_time.h"
#include <linux/jiffies.h>
#include <linux/time.h>
#include <linux/timer.h>
#include <linux/delay.h>
#include <asm/param.h>

int get_HZ(void)
{
	return HZ;
}

//  timer.h
void shannon_init_timer(shannon_timer_list *timer)
{
	init_timer((struct timer_list *)timer);
}

void shannon_add_timer(shannon_timer_list *timer, unsigned long expires)
{
	((struct timer_list *)timer)->expires = expires;
	add_timer((struct timer_list *)timer);
}

int shannon_del_timer_sync(shannon_timer_list *timer)
{
	return del_timer_sync((struct timer_list *)timer);
}

int shannon_del_timer(shannon_timer_list *timer)
{
	return del_timer((struct timer_list *)timer);
}

int shannon_mod_timer(shannon_timer_list *timer, unsigned long expires)
{
	return mod_timer((struct timer_list *)timer, expires);
}

int shannon_timer_pending(shannon_timer_list * timer)
{
	return timer_pending((struct timer_list *)timer);
}

void shannon_set_timer_context(shannon_timer_list *timer, unsigned long data, void (*f)(unsigned long))
{
	((struct timer_list *)timer)->data = data;
	((struct timer_list *)timer)->function = f;
}


//  delay.h
void shannon_msleep(unsigned int msecs)
{
	msleep(msecs);
}

void shannon_udelay(unsigned long usecs)
{
	udelay(usecs);
}


unsigned long get_jiffies(void)
{
	return jiffies;
}

void shannon_do_gettimeofday(struct shannon_timeval *tv)
{
	struct timeval time;
	do_gettimeofday(&time);
	tv->tv_sec = time.tv_sec;
	tv->tv_usec = time.tv_usec;
}

// jiffies.h
unsigned int shannon_jiffies_to_msecs(const unsigned long j)
{
	return jiffies_to_msecs(j);
}

unsigned int shannon_jiffies_to_usecs(const unsigned long j)
{
	return jiffies_to_usecs(j);
}
