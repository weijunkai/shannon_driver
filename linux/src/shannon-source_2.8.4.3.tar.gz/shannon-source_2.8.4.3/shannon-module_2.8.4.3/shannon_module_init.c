#include <linux/fs.h>
#include <linux/bio.h>
#include <linux/interrupt.h>
#include <linux/blkdev.h>
#include <linux/errno.h>
#include <linux/genhd.h>
#include <linux/kdev_t.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/version.h>
#include <linux/time.h>
#include <linux/completion.h>
#include <linux/random.h>
#include <linux/cdev.h>
#include <linux/miscdevice.h>

#include <linux/fcntl.h>  /* O_ACCMODE */
#include <linux/hdreg.h>  /* HDIO_GETGEO */

#include <linux/cpu.h>
#include <asm/processor.h>

#include "shannon_port.h"

#define SHANNON_CTRL_MINORS 64

int shannon_scsi_mode = 0;
module_param(shannon_scsi_mode, int, S_IRUGO|S_IWUSR);

struct shannon_dev;
extern u64 get_shannon_dev_sectors(struct shannon_dev *dev);
extern int sh_increase_users(struct shannon_dev *dev);
extern int sh_decrease_users(struct shannon_dev *dev);

struct shannon_list_head shannon_dev_list;
extern shannon_spinlock_t device_bitmap_lock;
shannon_workqueue_struct_t *scsi_wq;

//  blkdev operations
static int shannon_revalidate(struct gendisk *disk)
{
	struct shannon_dev *dev = disk->private_data;
	set_capacity(disk, get_shannon_dev_sectors(dev));
	return 0;
}

static int shannon_getgeo(struct block_device *bdev, struct hd_geometry *geo)
{
	struct shannon_dev *dev = bdev->bd_disk->private_data;

	/*
	 * get geometry: we have to fake one...  trim the size to a
	 * multiple of 2048 (1M): tell we have 32 sectors, 64 heads,
	 * whatever cylinders.
	 */
	geo->heads     = 32;
	geo->sectors   = 32;
	geo->cylinders = get_shannon_dev_sectors(dev) / (geo->heads * geo->sectors);
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)

static int shannon_open(struct block_device *bdev, fmode_t mode)
{
	struct shannon_dev *dev = bdev->bd_disk->private_data;
	return sh_increase_users(dev);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
static void shannon_release(struct gendisk *gd, fmode_t mode)
{
	struct shannon_dev *dev = gd->private_data;
	sh_decrease_users(dev);
}
#else
static int shannon_release(struct gendisk *gd, fmode_t mode)
{
	struct shannon_dev *dev = gd->private_data;
	sh_decrease_users(dev);
	return 0;
}
#endif

struct block_device_operations shannon_ops = {
	.owner		= THIS_MODULE,
	.getgeo		= shannon_getgeo,
	.revalidate_disk = shannon_revalidate,
	.open		= shannon_open,
	.release	= shannon_release,
};

#else

int shannon_open(struct inode *inode, struct file *filp)
{
	struct shannon_dev *dev = inode->i_bdev->bd_disk->private_data;
	return sh_increase_users(dev);
}

int shannon_release(struct inode *inode, struct file *filp)
{
	struct shannon_dev *dev = inode->i_bdev->bd_disk->private_data;
	sh_decrease_users(dev);
	return 0;
}

struct block_device_operations shannon_ops = {
	.owner		= THIS_MODULE,
	.getgeo		= shannon_getgeo,
	.revalidate_disk = shannon_revalidate,
	.open		= shannon_open,
	.release	= shannon_release,
};

#endif

//  control miscdevice
static int shannon_ctrl_miscdevice_open(struct inode *inode, struct file *filp)
{
	struct shannon_dev *sdev = NULL;
	int minor = iminor(inode);
	struct miscdevice *c = NULL;
	struct shannon_list_head *list;

	shannon_spin_lock_bh(&device_bitmap_lock);

	shannon_list_for_each(list, &shannon_dev_list) {
		sdev = get_shannon_dev_from_list(list);
		c = (struct miscdevice *)get_miscdevice_from_shannon_dev(sdev);
		if (c->minor == minor)
			break;
	}

	shannon_spin_unlock_bh(&device_bitmap_lock);

	BUG_ON(c->minor != minor);
	filp->private_data = sdev;

	return 0;
}

static int shannon_ctrl_miscdevice_release(struct inode *inode, struct file *filp)
{
	return 0;
}

extern long  shannon_ioctl(shannon_file_t *filp, unsigned int cmd, unsigned long arg);

static long  shannon_ioctl_wrapper(struct file *filp, unsigned int cmd, unsigned long arg)
{
	return shannon_ioctl(filp, cmd, arg);
}

struct file_operations shannon_ctrl_miscdevice_fops = {
	.owner		= THIS_MODULE,
	.open		= shannon_ctrl_miscdevice_open,
	.release	= shannon_ctrl_miscdevice_release,
	.unlocked_ioctl	= shannon_ioctl_wrapper,
};


static void miscdevice_init(struct miscdevice *md, char *cdev_name)
{
	memset(md, 0, sizeof(*md));
	md->minor = MISC_DYNAMIC_MINOR;
	md->name  = cdev_name;
	md->fops  = &shannon_ctrl_miscdevice_fops;
}

int shannon_create_miscdevice(struct shannon_dev *sdev, char *cdev_name)
{
	struct miscdevice *misc;
	int ret;
#if defined(__VMKLNX__)
	int minor=254;
#endif

	misc = (struct miscdevice *)get_miscdevice_from_shannon_dev(sdev);

	miscdevice_init(misc, cdev_name);

#if defined(__VMKLNX__)
	do
	{
	    misc->minor = minor--;
#endif
	    ret = misc_register(misc);
#if defined(__VMKLNX__)
	}
	while (ret < 0 && minor > 0);
#endif

	return ret;
}

int shannon_destroy_miscdevice(struct shannon_dev *sdev)
{
    struct miscdevice *misc;

    misc = (struct miscdevice *)get_miscdevice_from_shannon_dev(sdev);
    misc_deregister(misc);

    return 0;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20)
#define DEFINE_PCI_DEVICE_TABLE(_table) \
	const struct pci_device_id _table[] __devinitdata
#endif

//  module init & exit
#define PCI_VENDOR_ID_SHANNON	0x1cb0

static DEFINE_PCI_DEVICE_TABLE(shannon_id_table) = {
#if !defined(CONFIG_SHANNON_EMU) && !defined(CONFIG_SHANNON_EMU_MODULE)
	// { PCI_DEVICE(PCI_VENDOR_ID_XILINX, 0x0007), },
	{ PCI_DEVICE(PCI_VENDOR_ID_XILINX, 0x6024), },
	{ PCI_DEVICE(PCI_VENDOR_ID_SHANNON, 0x0265), },
	{ PCI_DEVICE(PCI_VENDOR_ID_SHANNON, 0x0275), },
	{ PCI_DEVICE(PCI_VENDOR_ID_SHANNON, 0x1275), },
	{ PCI_DEVICE(PCI_VENDOR_ID_SHANNON, 0x2275), },
#else
	{ PCI_DEVICE(PCI_VENDOR_ID_NVIDIA, 0x0774), }, /* Nvidia Audio device */
	{ PCI_DEVICE(0x8086, 0x27d8), },  /* for testing */
	{ PCI_DEVICE(0x8086, 0x1c20), },  /* for testing */
	{ PCI_DEVICE(0x1013, 0x00b8), },  /* for testing */
#endif
	{ 0, }
};
MODULE_DEVICE_TABLE(pci, shannon_id_table);

extern int shannon_scsi_probe(struct pci_dev *pdev, const struct pci_device_id *id);
extern void shannon_scsi_remove(struct pci_dev *pdev);
extern void shannon_remove(void *data, shannon_pci_dev_t *pdev);
extern int shannon_probe(shannon_pci_dev_t *pdev, const shannon_pci_device_id_t *id, struct shannon_scsi_private *data);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 8, 0)
static void shannon_remove_wrapper(struct pci_dev *pdev)
#else
static void __devexit shannon_remove_wrapper(struct pci_dev *pdev)
#endif
{
	if (shannon_scsi_mode)
		shannon_scsi_remove(pdev);
	else
		shannon_remove(NULL, pdev);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 8, 0)
static int shannon_probe_wrapper(struct pci_dev *pdev, const struct pci_device_id *id)
#else
static int __devinit shannon_probe_wrapper(struct pci_dev *pdev, const struct pci_device_id *id)
#endif
{
	if (shannon_scsi_mode)
		return shannon_scsi_probe(pdev, id);
	else
		return shannon_probe(pdev, id, NULL);
}

static struct pci_driver shannon_driver = {
	.name           = "shannon",
	.id_table       = shannon_id_table,
	.probe          = shannon_probe_wrapper,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 8, 0)
	.remove         = shannon_remove_wrapper,
#else
	.remove         = __devexit_p(shannon_remove_wrapper),
#endif
	.shutdown       = shannon_remove_wrapper,
};

extern shannon_kmem_cache_t *shannon_req_slab;
extern shannon_kmem_cache_t *shannon_bio_slab;
extern shannon_mempool_t *shannon_req_pool;
extern shannon_mempool_t *shannon_bio_pool;


extern int shannon_major;
extern int shannon_auto_attach;

extern int shannon_sector_size;
module_param(shannon_sector_size, int, S_IRUGO|S_IWUSR);
extern int shannon_debug_level;
module_param(shannon_debug_level, int, S_IRUGO|S_IWUSR);
extern int shannon_force_rw;
module_param(shannon_force_rw, int, S_IRUGO|S_IWUSR);
module_param(shannon_major, int, 0);
module_param(shannon_auto_attach, int, 0);
extern int shannon_pm_qos_value;
extern int shannon_pm_qos_disable;
module_param(shannon_pm_qos_value, int, S_IRUGO|S_IWUSR);
module_param(shannon_pm_qos_disable, int, S_IRUGO|S_IWUSR);
extern int shannon_use_iosched;
module_param(shannon_use_iosched, int, S_IRUGO|S_IWUSR);
extern int shannon_buffer_write;
module_param(shannon_buffer_write, int, S_IRUGO|S_IWUSR);
extern int shannon_disable_intervel_refresh_mbr;
module_param(shannon_disable_intervel_refresh_mbr, int, S_IRUGO|S_IWUSR);
extern int shannon_never_hang;
module_param(shannon_never_hang, int, S_IRUGO|S_IWUSR);

extern int shannon_alloc_mempool(void);
extern void shannon_free_mempool(void);

int has_dma_delay = 0;
int check_has_dma_delay(void)
{
#ifdef CONFIG_X86
	struct cpuinfo_x86 *c = NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 24)
	c = &cpu_data(0);
#else
	c = &cpu_data[0];
#endif /* end of LINUX_VERSION_CODE */
	has_dma_delay = !(c->x86_vendor == X86_VENDOR_INTEL);

	printk("cpu vendor_id: %s, has_dma_delay: %s.\n", c->x86_vendor_id, has_dma_delay ? "yes" : "no");
#else /* else of CONFIG_X86 */
#ifdef CONFIG_SHANNON_DMA_REORDER
	has_dma_delay = 1;
#else
	has_dma_delay = 0;
#endif
#endif /*end of CONFIG_X86 */

	return 0;
}

static int __init shannon_init(void)
{
	int result = -ENOMEM;

	if (shannon_scsi_mode)
		shannon_pm_qos_disable = 1;

	check_has_dma_delay();

	shannon_spin_lock_init(&device_bitmap_lock);
	SHANNON_INIT_LIST_HEAD(&shannon_dev_list);
	shannon_major = register_blkdev(shannon_major, "shannon");
	if (shannon_major <= 0)
		return -ENOMEM;
	scsi_wq = shannon_create_workqueue("shannon_scsi");
	if (scsi_wq == NULL) {
		debugs0("alloc shannon_scsi workqueue failed!\n");
		goto unregister_blkdev;
	}

	if (shannon_alloc_mempool())
		goto destroy_wq;

	result = pci_register_driver(&shannon_driver);
	if (result)
		goto free_mempool;

	return 0;

free_mempool:
	shannon_free_mempool();
destroy_wq:
	shannon_destroy_workqueue(scsi_wq);
unregister_blkdev:
	unregister_blkdev(shannon_major, "shannon");
	return result;
}

static void __exit shannon_exit(void)
{
	pci_unregister_driver(&shannon_driver);
	shannon_free_mempool();

	shannon_destroy_workqueue(scsi_wq);
	unregister_blkdev(shannon_major, "shannon");
}

MODULE_LICENSE("GPL");
MODULE_VERSION("2.8.4.3");
module_init(shannon_init);
module_exit(shannon_exit);
