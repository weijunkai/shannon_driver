#ifndef __SHANNON_SYSFS_H
#define __SHANNON_SYSFS_H

#include "shannon_kcore.h"

struct __shannon_kobject {
	RESERVE_MEM(152);
};

typedef struct __shannon_kobject shannon_kobject_t;

extern int shannon_sysfs_init(shannon_kobject_t *skobj);
extern void shannon_sysfs_exit(shannon_kobject_t *skobj);
extern shannon_device_t *shannon_hwmon_init(shannon_pci_dev_t *pdev);
extern void shannon_hwmon_exit(shannon_pci_dev_t *pdev, shannon_device_t *hwmon_dev);

struct shannon_dev;
//  functions below are implemented in shannon_sysfs_core.c
extern struct shannon_dev * to_shannon_dev(shannon_kobject_t *skobj);
extern void *to_shannon_disk(shannon_kobject_t *skobj);
extern char * shannon_disk_name(struct shannon_dev *sdev);
extern shannon_ssize_t model_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t firmware_version_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t firmware_build_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t driver_version_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t serial_number_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t configuration_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t block_size_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t use_dual_head_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t pci_info_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t power_on_seconds_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t power_cycle_count_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t user_capacity_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t physical_capacity_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t overprovision_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t free_blkcnt_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t static_bad_blkcnt_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t dynamic_bad_blkcnt_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t reconfig_support_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t seu_flag_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t seu_crc_error_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t seu_crc_error_history_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t seu_ecc_error_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t seu_ecc_error_history_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t estimated_life_left_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_write_sectors_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_write_bandwidth_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_write_iops_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_write_latency_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t total_write_sectors_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t total_write_bandwidth_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t write_amplifier_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t write_amplifier_lifetime_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_read_sectors_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_read_bandwidth_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_read_iops_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t host_read_latency_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_int_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_int_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_flash_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_flash_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_board_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temperature_board_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t voltage_int_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t voltage_int_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t voltage_aux_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t voltage_aux_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t ecc_failure_times_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t ecc_statistics_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t device_state_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t access_mode_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t reduced_write_reason_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t readonly_reason_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t pm_qos_value_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t pm_qos_value_store(struct shannon_dev *sdev, const char *buf, shannon_size_t count);
extern shannon_ssize_t service_tag_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t fpga_dna_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t udid_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t refresh_mbr_count_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t atomic_write_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t prioritize_write_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t name_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp1_input_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp1_label_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp1_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp1_crit_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp2_input_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp2_label_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp2_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp2_crit_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp3_input_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp3_label_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp3_max_show(struct shannon_dev *sdev, char *buf);
extern shannon_ssize_t temp3_crit_show(struct shannon_dev *sdev, char *buf);

#endif /* __SHANNON_SYSFS_H */
