void parity_init_for_reconfig(struct shannon_sb *sb, int group_index, int ppa, u8 head)
{
	struct shannon_dev *sdev = sb->sdev;
	struct shannon_request *req;
	struct shannon_lun *lun;
	int head_index = head & HEAD_INDEX_MASK;

	sb->sdev->parity_init_done[head_index] = 0;

	req = alloc_req(GFP_ATOMIC);
	set_req_debug_tag(req, PARITY_INIT_TAG, 0);
	req->opcode = sh_cmd_parity_init;
	req->data_luns = sb->min_data_luns;
	req->pba.lun = get_parity_lun(&sb->sub_group[group_index]);
	req->head = head;
	req->ppa = ppa;
	debugs0("sb=%d, lun=%d, group_index=%d, ppa=%d, head=0x%x.\n", sb->sb_index, req->pba.lun, group_index, ppa, head);
	lun = sdev->lun[req->pba.lun];
	shannon_parity_init_cmd(lun->lunset, req);

	return;
}

#define MAX_WAIT_MSECS		1500
int shannon_reconfig(struct shannon_dev *sdev)
{
	struct shannon_lun_bar *lun_section;
	struct shannon_lun *lun;
	struct shannon_lunset *lunset;
	u32 seu, error_count;
	int i, status, old_state, wait;

	seu = shannon_ioread32((u32 *)sdev->bar + SH_SEU_OFFSET);
	debugs0("%s: seu=0x%x.\n", sdev->cdev_name, seu);
	if (seu == 0) {
		debugs0("seu is misreported!.\n");
		return 0;
	} else if (seu == ~0) {
		check_plugout(sdev);
		if (sdev->plug_out == 0)
			sdev->state |= SHN_STATE_ERROR_BIT;
		debugs0("sdev->plug_out=%d, state=0x%x.\n", sdev->plug_out, sdev->state);
		return 0;
	}
	if (sdev->reconfig_times > MAX_RECONFIG_TIMES) {
		debugs0("%s: this device has been in readonly mode.\n", sdev->cdev_name);
		return 0;
	}
	stop_watchdog_timer(sdev);
	sdev->big_lock = 1;
	shannon_mutex_lock(&sdev->pick_sem);
	for (i = 0; i < sdev->lunset_count; i++)
		shannon_mutex_lock(&sdev->lunsets[i].lun_pick_sem);
	/* sdev->state_sem was hold before invoke shannon_reconfig */

	sdev->total_reconfig_times++;

	if ((get_jiffies() - sdev->first_jiffie) > get_HZ() * 60) {
		sdev->first_jiffie = get_jiffies();
		sdev->reconfig_times = 1;
	} else {
		sdev->reconfig_times++;
		if (sdev->reconfig_times > MAX_RECONFIG_TIMES) {
			shannon_set_reg((u32 *)sdev->bar + SH_SEU_INTERRUPT_OFFSET, MASK_SEU_INTERRUPT, 1);
			shannon_printk(KERN_ERR "%s: seu register=0x%x, set to readonly.\n", sdev->cdev_name, seu);
			shannon_set_bit(SHN_REASON_SEU_ERROR, &sdev->readonly_reason);
			update_access_mode(sdev);
			goto out;
		}
	}
	debugs0("%s: wait command queue is empty.\n", sdev->cdev_name);
	while (!all_cmd_queue_is_empty(sdev))
		shannon_msleep(1);
	debugs0("%s: command queue is empty now.\n", sdev->cdev_name);

	debugs0("%s: fill page stripe.....\n", sdev->cdev_name);
	while ((sdev->lun_in_group[HOT_INDEX] != 0) || \
			(sdev->wr_group[HOT_INDEX] != 0) || \
			(sdev->wr_plane[HOT_INDEX] != 0) || \
			(sdev->wr_logicb[HOT_INDEX] != 0))
		send_dummy_req(sdev, HOT_HEAD);

	while ((sdev->lun_in_group[COLD_INDEX] != 0) || \
			(sdev->wr_group[COLD_INDEX] != 0) || \
			(sdev->wr_plane[COLD_INDEX] != 0) || \
			(sdev->wr_logicb[COLD_INDEX] != 0))
		send_dummy_req(sdev, COLD_HEAD);

	debugs0("%s: wait command queue is empty.\n", sdev->cdev_name);
	while (!all_cmd_queue_is_empty(sdev))
		shannon_msleep(1);
	debugs0("%s: command queue is empty now.\n", sdev->cdev_name);

	/* disable irq */
	shannon_memset(sdev->potential_interrupt_vectors, 0xFF, sizeof(sdev->potential_interrupt_vectors));
	read_bufq_interrupt_vector(sdev);
	read_other_interrupt_vector(sdev);
	shannon_clear_interrupt(sdev);
	shannon_memset(sdev->potential_interrupt_vectors, 0, sizeof(sdev->potential_interrupt_vectors));

	old_state = sdev->state;
	sdev->state = SHN_STATE_RECONFIG;

	shannon_msleep(10);
	debugs0("%s: start reconfig...\n", sdev->cdev_name);
	shannon_set_reg((u32 *)sdev->bar + SH_RECONFIG_CONTROL_OFFSET, RECONFIG_START, 1);
	wait = 0;
	do {
		if (wait > MAX_WAIT_MSECS) {
			sdev->state = old_state | SHN_STATE_ERROR_BIT;
			shannon_queue_work(sdev->watchdog_wq, &sdev->watchdog_work);
			debugs0("reconfig timeout! set state=0x%x.\n", sdev->state);
			goto out;
		}
		shannon_msleep(1);
		status = shannon_read_reg((u32 *)sdev->bar + SH_RECONFIG_STATUS_OFFSET, RECONFIG_STATUS);
		wait++;
	} while (status);
	debugs0("%s: status 1 =%d.\n", sdev->cdev_name, status);
	shannon_set_reg((u32 *)sdev->bar + SH_RECONFIG_CONTROL_OFFSET, RECONFIG_START, 0);
	shannon_msleep(100);
	error_count = shannon_read_reg((u32 *)sdev->bar + SH_RECONFIG_STATUS_OFFSET, ERROR_COUNT);
	seu = shannon_ioread32((u32 *)sdev->bar + SH_SEU_OFFSET);
	debugs0("%s: check seu=0x%x.\n", sdev->cdev_name, seu);
	if ((error_count == 0) && (seu >> SH_SEU_CRC_ERROR_SHIFT)) {
		shannon_set_reg((u32 *)sdev->bar + SH_RECONFIG_CONTROL_OFFSET, RECONFIG_START, 1);
		wait = 0;
		do {
			if (wait > MAX_WAIT_MSECS) {
				sdev->state = old_state | SHN_STATE_ERROR_BIT;
				shannon_queue_work(sdev->watchdog_wq, &sdev->watchdog_work);
				debugs0("reconfig timeout! set state=0x%x.\n", sdev->state);
				goto out;
			}
			shannon_msleep(1);
			status = shannon_read_reg((u32 *)sdev->bar + SH_RECONFIG_STATUS_OFFSET, RECONFIG_STATUS);
			wait++;
		} while (status);
		debugs0("%s: status 2=%d.\n", sdev->cdev_name, status);
		shannon_set_reg((u32 *)sdev->bar + SH_RECONFIG_CONTROL_OFFSET, RECONFIG_START, 0);
		shannon_msleep(100);

		error_count = shannon_read_reg((u32 *)sdev->bar + SH_RECONFIG_STATUS_OFFSET, ERROR_COUNT);
		seu = shannon_ioread32((u32 *)sdev->bar + SH_SEU_OFFSET);
		debugs0("%s: check seu again. seu=0x%x.\n", sdev->cdev_name, seu);
	}

	if (error_count || (seu >> SH_SEU_CRC_ERROR_SHIFT)) {
		shannon_printk(KERN_ERR "%s: reconfig error count=%d, seu register=0x%x, set to readonly.\n", sdev->cdev_name, error_count, seu);
		shannon_set_bit(SHN_REASON_SEU_ERROR, &sdev->readonly_reason);
		update_access_mode(sdev);
	}

	debugs0("%s: reconfig finished.\n", sdev->cdev_name);
	/* disable irq */
	shannon_memset(sdev->potential_interrupt_vectors, 0xFF, sizeof(sdev->potential_interrupt_vectors));
	read_bufq_interrupt_vector(sdev);
	read_other_interrupt_vector(sdev);
	shannon_clear_interrupt(sdev);
	shannon_memset(sdev->potential_interrupt_vectors, 0, sizeof(sdev->potential_interrupt_vectors));

	shannon_init_norflash(sdev);
	init_global_config_regs_for_flashid(sdev);
#ifdef CONFIG_SHANNON_DMA_QUEUE_64BIT
	shannon_set_reg(&sdev->global_bar->flash, DMA_QUEUE_64BIT, 1);
#endif
	lun_section = (struct shannon_lun_bar *)((u32 *)sdev->bar + 256);
	reset_all_lunset(sdev, lun_section);
	shannon_set_reg(&sdev->global_bar->flash, FLASH_MODE, sdev->ifmode == TOGGLE_MODE ? TOGGLE_MODE : ONFI_ASYNC_MODE);

	if ((sdev->hardware_version >= 5) && (sdev->microcode_length > 0)) {
		write_advanced_read_microcode(sdev);
		sdev->advanced_read_support = 1;
	} else
		sdev->advanced_read_support = 0;
/*
	shannon_memset(sdev->potential_interrupt_vectors, 0xFF, sizeof(sdev->potential_interrupt_vectors));
	read_bufq_interrupt_vector(sdev);
	read_other_interrupt_vector(sdev);
	shannon_clear_interrupt(sdev);
	shannon_memset(sdev->potential_interrupt_vectors, 0, sizeof(sdev->potential_interrupt_vectors));
*/
	for (i = 0; i < sdev->lunset_count; i++) {
		shannon_pci_free_consistent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->lunsets[i].sq_addr, sdev->lunsets[i].sq_dma_addr);
		shannon_pci_free_consistent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->lunsets[i].cq_addr, sdev->lunsets[i].cq_dma_addr);
		sdev->lunsets[i].sq_addr = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE,
				&sdev->lunsets[i].sq_dma_addr, GFP_SHANNON);
		if (sdev->lunsets[i].sq_addr == NULL)
			debugs0("%s: sq_addr %d failed.\n", sdev->cdev_name, i);
		sdev->lunsets[i].cq_addr = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE,
				&sdev->lunsets[i].cq_dma_addr, GFP_SHANNON);
		if (sdev->lunsets[i].cq_addr == NULL)
			debugs0("%s: cq_addr %d failed.\n", sdev->cdev_name, i);

		shannon_writel((u32)sdev->lunsets[i].sq_dma_addr, &sdev->lunsets[i].lun_bar->sq_dma_addr0);
		shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->lunsets[i].sq_dma_addr >> 32) : 0, &sdev->lunsets[i].lun_bar->sq_dma_addr1);
		shannon_writel((u32)sdev->lunsets[i].cq_dma_addr, &sdev->lunsets[i].lun_bar->cq_dma_addr0);
		shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->lunsets[i].cq_dma_addr >> 32) : 0, &sdev->lunsets[i].lun_bar->cq_dma_addr1);

		sdev->lunsets[i].sq_hw_head = shannon_readl(&sdev->lunsets[i].lun_bar->sq_head);
		sdev->lunsets[i].sq_head = sdev->lunsets[i].sq_hw_head;
		sdev->lunsets[i].cq_hw_head = shannon_readl(&sdev->lunsets[i].lun_bar->cq_head);
		sdev->lunsets[i].cq_head = sdev->lunsets[i].cq_hw_head;
		sdev->lunsets[i].cq_tail = sdev->lunsets[i].cq_head;

		sdev->lunsets[i].sq_head_tmp = sdev->lunsets[i].sq_head;
	}

	for (i = 0; i < sdev->lun_count; i++) {
		if (!shannon_test_bit(sdev->lun[i]->phy_lun_num, (unsigned long *)sdev->mbr.bad_phy_lun_map))
			lun_set_feature_over_drive(sdev->lun[i], sdev->overdrive);
		lun = sdev->lun[i];
		lunset= lun->lunset;
		debugs1("set feature: lun=%d, lunset=%d, sq_head_tmp=%d, sq_head=%d, cq_head=%d, cq_tail=%d.\n",
				i, lunset->index, lunset->sq_head_tmp, lunset->sq_head, lunset->cq_head, lunset->cq_tail);
	}

	for (i = 0; i < sdev->lun_count; i++) {
		if (!shannon_test_bit(sdev->lun[i]->phy_lun_num, (unsigned long *)sdev->mbr.bad_phy_lun_map))
			if (sdev->ifmode == ONFI_SYNC_MODE)
				lun_set_feature_sync_mode(sdev->lun[i]);
		lun = sdev->lun[i];
		lunset= lun->lunset;
		debugs1("set sync: lun=%d, lunset=%d, sq_head_tmp=%d, sq_head=%d, cq_head=%d, cq_tail=%d.\n",
				i, lunset->index, lunset->sq_head_tmp, lunset->sq_head, lunset->cq_head, lunset->cq_tail);
	}

	shannon_dma_free_coherent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->bufq_sq_addr[0], sdev->bufq_sq_dma_addr[0]);
	shannon_dma_free_coherent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->bufq_cq_addr[0], sdev->bufq_cq_dma_addr[0]);
	shannon_dma_free_coherent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->bufq_sq_addr[1], sdev->bufq_sq_dma_addr[1]);
	shannon_dma_free_coherent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->bufq_cq_addr[1], sdev->bufq_cq_dma_addr[1]);
	shannon_dma_free_coherent(sdev->pci_dev, QUEUE_SIZE, (void *)sdev->bufq_ack_cq_addr, sdev->bufq_ack_cq_dma_addr);

	sdev->bufq_sq_addr[0] = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE, &sdev->bufq_sq_dma_addr[0], GFP_SHANNON);
	sdev->bufq_cq_addr[0] = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE, &sdev->bufq_cq_dma_addr[0], GFP_SHANNON);
	sdev->bufq_sq_addr[1] = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE, &sdev->bufq_sq_dma_addr[1], GFP_SHANNON);
	sdev->bufq_cq_addr[1] = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE, &sdev->bufq_cq_dma_addr[1], GFP_SHANNON);
	sdev->bufq_ack_cq_addr = shannon_dma_alloc_coherent(sdev->pci_dev, QUEUE_SIZE, &sdev->bufq_ack_cq_dma_addr, GFP_SHANNON);

	sdev->bufq_bar[0] = (struct shannon_lun_bar *)((u32 *)sdev->bar + 256 + (8 * sdev->intr_big_shift[0]));
	shannon_writel((u32)sdev->bufq_sq_dma_addr[0], &sdev->bufq_bar[0]->sq_dma_addr0);
	shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->bufq_sq_dma_addr[0] >> 32) : 0, &sdev->bufq_bar[0]->sq_dma_addr1);
	shannon_writel((u32)sdev->bufq_cq_dma_addr[0], &sdev->bufq_bar[0]->cq_dma_addr0);
	shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->bufq_cq_dma_addr[0] >> 32) : 0, &sdev->bufq_bar[0]->cq_dma_addr1);

	sdev->bufq_bar[1] = (struct shannon_lun_bar *)((u32 *)sdev->bar + 256 + (8 * sdev->intr_big_shift[1]));
	shannon_writel((u32)sdev->bufq_sq_dma_addr[1], &sdev->bufq_bar[1]->sq_dma_addr0);
	shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->bufq_sq_dma_addr[1] >> 32) : 0, &sdev->bufq_bar[1]->sq_dma_addr1);
	shannon_writel((u32)sdev->bufq_cq_dma_addr[1], &sdev->bufq_bar[1]->cq_dma_addr0);
	shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->bufq_cq_dma_addr[1] >> 32) : 0, &sdev->bufq_bar[1]->cq_dma_addr1);

	sdev->bufq_ack_bar = (struct shannon_lun_bar *)((u32 *)sdev->bar + 256 + (8 * sdev->bufq_ack_intr_shift));
	shannon_writel((u32)sdev->bufq_ack_cq_dma_addr, &sdev->bufq_ack_bar->cq_dma_addr0);
	shannon_writel((sizeof(dma_addr_t) > 4) ? (u32)(sdev->bufq_ack_cq_dma_addr >> 32) : 0, &sdev->bufq_ack_bar->cq_dma_addr1);

	for (i = 0; i < 2; i++) {
		sdev->bufq_sq_hw_head[i] = shannon_readl(&sdev->bufq_bar[i]->sq_head);
		sdev->bufq_sq_head[i] = sdev->bufq_sq_hw_head[i];
		sdev->bufq_cq_hw_head[i] = shannon_readl(&sdev->bufq_bar[i]->cq_head);
		sdev->bufq_cq_head[i] = sdev->bufq_cq_hw_head[i];
		sdev->bufq_cq_tail[i] = sdev->bufq_cq_head[i];
		sdev->bufq_sq_head_tmp[i] = sdev->bufq_sq_head[i];
	}
	sdev->bufq_ack_cq_hw_head = shannon_readl(&sdev->bufq_ack_bar->cq_head);
	sdev->bufq_ack_cq_head = sdev->bufq_ack_cq_hw_head;
	sdev->bufq_ack_cq_tail = sdev->bufq_ack_cq_head;
	shannon_writel(sdev->bufq_ack_cq_tail, &sdev->bufq_ack_bar->ack_cq_tail);

	shannon_pci_free_consistent(sdev->pci_dev, sdev->nand_page_size, sdev->dummy_page, sdev->dummy_dma_page);
	sdev->dummy_page = shannon_pci_alloc_consistent(sdev->pci_dev, sdev->nand_page_size, &sdev->dummy_dma_page);

	init_global_config_regs(sdev);
	set_available_raid_stripes(sdev);

	for (i = 0; i < sdev->lunset_count; i++) {
		sdev->lunsets[i].sq_hw_head = shannon_readl(&sdev->lunsets[i].lun_bar->sq_head);
		sdev->lunsets[i].sq_head = sdev->lunsets[i].sq_hw_head;
		sdev->lunsets[i].cq_hw_head = shannon_readl(&sdev->lunsets[i].lun_bar->cq_head);
		sdev->lunsets[i].cq_head = sdev->lunsets[i].cq_hw_head;
		sdev->lunsets[i].cq_tail = sdev->lunsets[i].cq_head;

		sdev->lunsets[i].sq_head_tmp = sdev->lunsets[i].sq_head;
		debugs1("lunset=%d, sq_head_tmp=%d, cq_tail=%d.\n", i, sdev->lunsets[i].sq_head_tmp, sdev->lunsets[i].cq_tail);
	}

	shannon_memset(sdev->potential_interrupt_vectors, 0xFF, sizeof(sdev->potential_interrupt_vectors));
	read_bufq_interrupt_vector(sdev);
	read_other_interrupt_vector(sdev);
	shannon_clear_interrupt(sdev);
	shannon_memset(sdev->potential_interrupt_vectors, 0, sizeof(sdev->potential_interrupt_vectors));

	debugs0("%s: send parity_init.\n", sdev->cdev_name);
	parity_init_for_reconfig(sdev->active_blk[0], sdev->wr_group[0], sdev->wr_sb[0] * sdev->pages_in_eblock * sdev->planes + sdev->wr_chunk[0], write_head[0]);
	parity_init_for_reconfig(sdev->active_blk[1], sdev->wr_group[1], sdev->wr_sb[1] * sdev->pages_in_eblock * sdev->planes + sdev->wr_chunk[1], write_head[1]);

	sdev->state = old_state;
	shannon_memset(sdev->potential_interrupt_vectors, 0xFF, sizeof(sdev->potential_interrupt_vectors));
	write_interrupt_vector(sdev);

out:
	for (i = 0; i < sdev->lunset_count; i++) {
		shannon_mutex_unlock(&sdev->lunsets[i].lun_pick_sem);
		if (!shannon_list_empty(&sdev->lunsets[i].req_queue))
			shannon_queue_work(sdev->shannon_read_wq, &sdev->lunsets[i].submit_work);
	}
	shannon_mutex_unlock(&sdev->pick_sem);
	sdev->big_lock = 0;
	shannon_wake_up(&sdev->big_lock_event);
	shannon_wake_up(&sdev->limit_req_queue);
	if (!shannon_list_empty(&sdev->req_queue))
		shannon_queue_work(sdev->shannon_wq, &sdev->work);
	start_watchdog_timer(sdev, WATCHDOG_SECONDS);

	debugs0("exit.\n");
	return 0;
}

void shannon_reconfig_task(struct shannon_work_struct *work)
{
	struct shannon_dev *dev = container_of(work, struct shannon_dev, reconfig_work);
	shannon_reconfig(dev);
}
