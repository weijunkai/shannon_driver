#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <asm/uaccess.h>
#include <linux/cdev.h>

#include "shannon_device.h"

int debug_cdev_open(struct inode *inode, struct file *file)
{
	struct debug_cdev *dev;

	dev = container_of((shannon_cdev_t *)inode->i_cdev, struct debug_cdev, cdev);
	file->private_data = dev;

	return 0;
}

int debug_cdev_release(struct inode *inode, struct file *file)
{
	return 0;
}

ssize_t debug_cdev_read(struct file *file, char __user *buf, size_t count, loff_t *f_pos)
{
	struct debug_cdev *dev = file->private_data;
	ssize_t ret = 0;

	if (*f_pos >= dev->size)
		goto out;
	if (*f_pos + count > dev->size)
		count = dev->size - *f_pos;

	if(copy_to_user(buf, dev->buf + *f_pos, count)) {
		ret = -EFAULT;
		goto out;
	}

	*f_pos += count;
	ret = count;
out:
	return ret;
}

ssize_t debug_cdev_write(struct file *file, const char __user *buf, size_t count, loff_t *f_pos)
{
	struct debug_cdev *dev = file->private_data;
	ssize_t ret = 0;

	if (*f_pos >= dev->size)
		goto out;
	if (*f_pos + count > dev->size)
		count = dev->size - *f_pos;

	if (copy_from_user(dev->buf + *f_pos, buf, count)) {
		printk("%s(): copy_from_user failed.\n", __func__);
		ret = -EFAULT;
		goto out;
	}

	*f_pos += count;
	ret = count;
out:
	return ret;
}

loff_t debug_cdev_llseek(struct file *filp, loff_t off, int whence)
{
	struct debug_cdev *dev = filp->private_data;
	loff_t newpos;

	switch(whence) {
	case SEEK_SET:
		newpos = off;
		break;
	case SEEK_CUR:
		newpos = filp->f_pos + off;
		break;
	case SEEK_END:
		newpos = dev->size + off;
		break;
	default: /* can't happen */
		return -EINVAL;
	}

	if (newpos < 0) return -EINVAL;
	filp->f_pos = newpos;
	return newpos;
}

struct file_operations debug_cdev_fops = {
	.owner	= THIS_MODULE,
	.open	= debug_cdev_open,
	.release = debug_cdev_release,
	.read	= debug_cdev_read,
	.write	= debug_cdev_write,
	.llseek = debug_cdev_llseek,
};
EXPORT_SYMBOL(debug_cdev_fops);
