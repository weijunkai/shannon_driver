#include "shannon_pci.h"
#include <linux/pci.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19)
#include <linux/pci_hotplug.h>
#endif

void shannon_pci_disable_device(shannon_pci_dev_t *dev)
{
	pci_disable_device((struct pci_dev *)dev);
}

void shannon_pci_set_master(shannon_pci_dev_t *dev)
{
	pci_set_master((struct pci_dev *)dev);
}

void * shannon_pci_alloc_consistent(shannon_pci_dev_t *hwdev, shannon_size_t size, shannon_dma_addr_t *dma_handle)
{
	return pci_alloc_consistent((struct pci_dev *)hwdev, size, dma_handle);
}

void shannon_pci_free_consistent(shannon_pci_dev_t *hwdev, shannon_size_t size, void *vaddr, shannon_dma_addr_t dma_handle)
{
	pci_free_consistent((struct pci_dev *)hwdev, size, vaddr, dma_handle);
}

void shannon_pci_set_drvdata(shannon_pci_dev_t *pdev, void *data)
{
	pci_set_drvdata((struct pci_dev *)pdev, data);
}

int shannon_pci_enable_device(shannon_pci_dev_t *dev)
{
	return pci_enable_device((struct pci_dev *)dev);
}

int shannon_pci_request_region(shannon_pci_dev_t *dev, int i, const char *p)
{
	return pci_request_region((struct pci_dev *)dev, i, p);
}

void shannon_pci_release_regions(shannon_pci_dev_t *pdev)
{
	pci_release_regions((struct pci_dev *)pdev);
}

shannon_resource_size_t shannon_pci_resource_start(shannon_pci_dev_t *dev, int bar)
{
	return pci_resource_start((struct pci_dev *)dev, bar);
}

shannon_resource_size_t shannon_pci_resource_len(shannon_pci_dev_t *dev, int bar)
{
	return pci_resource_len((struct pci_dev *)dev, bar);
}

int shannon_pci_enable_msi(shannon_pci_dev_t *dev)
{
	return pci_enable_msi((struct pci_dev *)dev);
}

void shannon_pci_disable_msi(shannon_pci_dev_t *dev)
{
	pci_disable_msi((struct pci_dev *)dev);
}

int check_hot_pluggable(shannon_pci_dev_t *pdev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)
	struct pci_dev *pci_dev = ((struct pci_dev *)pdev);

	if ((pci_dev->slot == NULL) || (pci_dev->slot->hotplug == NULL))
		return 0;
	else
		return 1;
#else
	return 0;
#endif
}

int shannon_get_adapter_status(shannon_pci_dev_t *pdev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)
	struct pci_dev *dev = ((struct pci_dev *)pdev);
	struct hotplug_slot *hotplug = dev->slot->hotplug;
	int ret;
	u8 adapter_status;

	ret = hotplug->ops->get_adapter_status(hotplug, &adapter_status);
	if (ret) {
		printk("%s(): get adapter status failed!\n", __func__);
		return ret;
	}

	return adapter_status;
#else
	return 1;
#endif
}

int shannon_disable_slot(shannon_pci_dev_t *pdev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)
	struct pci_dev *dev = ((struct pci_dev *)pdev);
	struct hotplug_slot *hotplug = dev->slot->hotplug;

	hotplug->ops->disable_slot(hotplug);
#endif
	return 0;
}

static inline int shannon_pci_pcie_cap(struct pci_dev *dev)
{
	return pci_find_capability(dev, PCI_CAP_ID_EXP);
}

void shannon_set_max_payload_size(shannon_pci_dev_t *pdev)
{
	u16 val, bus_val, mps, bus_mps;
	struct pci_dev *dev = (struct pci_dev *)pdev;
	int dev_cap, bus_cap;

	dev_cap = shannon_pci_pcie_cap(dev);
	if (dev_cap == 0)
		return;
	pci_read_config_word(dev, dev_cap + PCI_EXP_DEVCTL, &val);
	bus_cap = shannon_pci_pcie_cap(dev->bus->self);
	if (bus_cap == 0)
		return;
	pci_read_config_word(dev->bus->self, bus_cap + PCI_EXP_DEVCTL, &bus_val);
	mps = val & PCI_EXP_DEVCTL_PAYLOAD;
	bus_mps = bus_val & PCI_EXP_DEVCTL_PAYLOAD;
	if (mps != bus_mps) {
		val &= ~PCI_EXP_DEVCTL_PAYLOAD;
		val |= bus_mps;
		pci_write_config_dword(dev, dev_cap + PCI_EXP_DEVCTL, val);
	}
}

void *shannon_pci_get_drvdata(shannon_pci_dev_t *pdev)
{
	return pci_get_drvdata((struct pci_dev *)pdev);
}

int shannon_pcie_set_readrq(shannon_pci_dev_t *pdev, int rq)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 23)
	return pcie_set_readrq((struct pci_dev *)pdev, rq);
#else
	struct pci_dev * dev = (struct pci_dev *)pdev;
	int cap, err = -EINVAL;
	u16 ctl, v;

	if (rq < 128 || rq > 4096 || (rq & (rq-1)))
		goto out;

	v = (ffs(rq) - 8) << 12;

	cap = pci_find_capability(dev, PCI_CAP_ID_EXP);
	if (!cap)
		goto out;

	err = pci_read_config_word(dev, cap + PCI_EXP_DEVCTL, &ctl);
	if (err)
		goto out;

	if ((ctl & PCI_EXP_DEVCTL_READRQ) != v) {
		ctl &= ~PCI_EXP_DEVCTL_READRQ;
		ctl |= v;
		err = pci_write_config_dword(dev, cap + PCI_EXP_DEVCTL, ctl);
	}

out:
	return err;
#endif
}

void get_pci_info(shannon_pci_dev_t *pdev, struct shannon_pci_info *info)
{
	struct pci_dev *pci_dev = (struct pci_dev *)pdev;

	int cap = -EINVAL;

	info->devfn = pci_dev->devfn;
	info->vendor_id = pci_dev->vendor;
	info->device_id = pci_dev->device;
	info->subsystem_vendor_id = pci_dev->subsystem_vendor;
	info->subsystem_device_id = pci_dev->subsystem_device;
	info->class = pci_dev->class;
	if (pci_dev->bus)
		info->pci_bus_number = pci_dev->bus->number;
	else
		info->pci_bus_number = 255;
	info->pci_slot_number = PCI_SLOT(pci_dev->devfn);
	info->pci_func_number = PCI_FUNC(pci_dev->devfn);

	cap = pci_find_capability(pci_dev, PCI_CAP_ID_EXP);

	if (cap) {
		if (pci_read_config_word(pci_dev, cap + PCI_EXP_LNKSTA, &info->lnksta))
			info->lnksta = 0;
		if (pci_read_config_dword(pci_dev, cap + PCI_EXP_LNKCAP, &info->lnkcap))
			info->lnkcap = 0;
	} else {
		info->lnksta = 0;
		info->lnkcap = 0;
	}
}

unsigned int get_pci_irq_num(shannon_pci_dev_t *pdev)
{
	return ((struct pci_dev *)pdev)->irq;
}

shannon_device_t *get_device_from_pci_dev(shannon_pci_dev_t *pdev)
{
	return (shannon_device_t *)(&(((struct pci_dev *)pdev)->dev));
}
