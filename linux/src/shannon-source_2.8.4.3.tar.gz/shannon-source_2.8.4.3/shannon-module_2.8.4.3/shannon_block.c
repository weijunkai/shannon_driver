#include <linux/fs.h>
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/blkdev.h>
#include <linux/genhd.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/spinlock.h>

#include "shannon_block.h"
#include "shannon_device.h"
#include "shannon_time.h"

int shannon_use_iosched = 0;

//  genhd.h
shannon_gendisk_t *shannon_alloc_disk(int minors)
{
	return alloc_disk(minors);
}

extern struct block_device_operations shannon_ops;
int shannon_init_gendisk(shannon_gendisk_t *disk, char *name, int major, int minor_span, int first_minor, shannon_request_queue_t *rq, void *pri)
{
	struct gendisk *gd = (struct gendisk *)disk;

	snprintf(gd->disk_name, 32, name);
	gd->major = major;
	gd->minors = minor_span;
	gd->first_minor = first_minor;
	gd->queue = (struct request_queue *)rq;
	gd->private_data = pri;
	gd->fops = &shannon_ops;

	return 0;
}

void shannon_set_capacity(shannon_gendisk_t *disk, shannon_sector_t size)
{
	set_capacity((struct gendisk *)disk, size);
}

void shannon_set_disk_ro(shannon_gendisk_t *disk, int flag)
{
	set_disk_ro((struct gendisk *)disk, flag);
}

void shannon_add_disk(shannon_gendisk_t *disk)
{
	add_disk((struct gendisk *)disk);
}

void shannon_del_gendisk(shannon_gendisk_t *gp)
{
	del_gendisk((struct gendisk *)gp);
}

//  fs.h
int shannon_register_blkdev(unsigned int major, const char *name)
{
	return register_blkdev(major, name);
}

void shannon_unregister_blkdev(unsigned int major, const char *name)
{
	unregister_blkdev(major, name);
}

//  blkdev.h
void shannon_blk_queue_block_size(shannon_request_queue_t *queue, unsigned int logical_size, unsigned int physical_size)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)

	blk_queue_logical_block_size((struct request_queue *)queue, logical_size);
	blk_queue_physical_block_size((struct request_queue *)queue, physical_size);

#else

	blk_queue_hardsect_size((struct request_queue *)queue, logical_size);

#endif
}

void shannon_blk_queue_max_hw_sectors(shannon_request_queue_t *q, unsigned int max_hw_sectors)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	blk_queue_max_hw_sectors((struct request_queue *)q, max_hw_sectors);
#else
	blk_queue_max_sectors((struct request_queue *)q, max_hw_sectors);
#endif
}

void shannon_blk_queue_io_min(shannon_request_queue_t *queue, unsigned int min)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	blk_queue_io_min((struct request_queue *)queue, min);
#endif
}

void shannon_blk_queue_io_opt(shannon_request_queue_t *queue, unsigned int opt)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29)
	blk_queue_io_opt((struct request_queue *)queue, opt);
#endif
}

static int shannon_should_trim_bio(shannon_bio_t *bio)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36)
	return ((struct bio *)bio)->bi_rw & REQ_DISCARD;
#else
#if LINUX_VERSION_CODE == KERNEL_VERSION(2, 6, 28)
	return bio_discard((struct bio *)bio);
#else
	return bio_rw_flagged((struct bio *)bio, BIO_RW_DISCARD);
#endif
#endif

#else
	return 0;
#endif
}


void shannon_queue_flag_set(int flag, shannon_request_queue_t *queue)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)

	queue_flag_set_unlocked(flag, (struct request_queue *)queue);

#else

	set_bit(flag, &(((struct request_queue *)queue)->queue_flags));

#endif
}


void shannon_queue_flag_clear(int flag, shannon_request_queue_t *queue)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 26)

	queue_flag_clear_unlocked(flag, (struct request_queue *)queue);

#else

	clear_bit(flag, &(((struct request_queue *)queue)->queue_flags));

#endif
}

void shannon_trim_setting(shannon_request_queue_t *queue)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 33)
	((struct request_queue *)queue)->limits.discard_granularity = PAGE_SIZE;
#endif
	((struct request_queue *)queue)->limits.max_discard_sectors = (UINT_MAX >> 9) & ~7;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37)
	((struct request_queue *)queue)->limits.discard_zeroes_data = 1;
#endif
	queue_flag_set_unlocked(QUEUE_FLAG_DISCARD, (struct request_queue *)queue);

#endif
}

void shannon_rotational_setting(shannon_request_queue_t *queue)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
	shannon_queue_flag_set(QUEUE_FLAG_NONROT, queue);
#endif
}

void shannon_blk_cleanup_queue(shannon_request_queue_t *q)
{
	blk_cleanup_queue((struct request_queue *)q);
}

//  bio.h
static void shannon_bio_endio(shannon_bio_t *bio, int error)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)

	if (error)
		bio_endio((struct bio *)bio, 0, error);
	else
		bio_endio((struct bio *)bio, ((struct bio *)bio)->bi_size, 0);

#else

	bio_endio((struct bio *)bio, error);

#endif
}

int shannon_bio_flagged(shannon_bio_t *bio, unsigned int flag)
{
	return bio_flagged((struct bio *)bio, flag);
}

unsigned long shannon_bio_data_dir(shannon_bio_t *bio)
{
	return bio_data_dir((struct bio *)bio);
}

static unsigned int shannon_bio_segments(shannon_bio_t *bio)
{
	return bio_segments((struct bio *)bio);
}

static unsigned int get_bi_size(shannon_bio_t *bio)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)
	return ((struct bio *)bio)->bi_iter.bi_size;
#else
	return ((struct bio *)bio)->bi_size;
#endif
}

static shannon_sector_t get_bi_sector(shannon_bio_t *bio)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)
	return ((struct bio *)bio)->bi_iter.bi_sector;
#else
	return ((struct bio *)bio)->bi_sector;
#endif
}

extern shannon_gendisk_t *get_gendisk_from_sdev(struct shannon_dev *sdev);
extern unsigned int get_logicb_size(struct shannon_dev *sdev);
extern unsigned int get_logicb_shift(struct shannon_dev *sdev);

extern int shannon_check_availability(struct shannon_dev *sdev);
extern int shannon_disk_readonly(struct shannon_dev *sdev);
extern int shannon_submit_bio(struct shannon_dev *sdev, struct shannon_bio *sbio);
extern void shannon_discard(struct shannon_dev *sdev, logicb_t start_lba, logicb_t end_lba);

#ifdef CONFIG_SHANNON_DEBUG
void set_sbio_debug_tag(struct shannon_bio *sbio, unsigned long tag)
{
	sbio->tag = tag;
}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)
int shannon_convert_bio(struct shannon_dev *sdev, struct shannon_bio *sbio, shannon_bio_t *lbio)
{
	shannon_sg_list_t *sg = NULL;
	struct bio *bio = (struct bio *)lbio;
	struct bio_vec bvec;
	int offset, remained_size, map_size = 0, undone = 0;
	unsigned int logicb_size = get_logicb_size(sdev);
	struct bvec_iter iter;

	sbio->segments = shannon_bio_segments(lbio);
	sbio->sg_count = 2 * sbio->segments + 1;
	sbio->sg = shannon_sg_alloc(sbio->sg_count, GFP_SHANNON);
	if (sbio->sg == NULL) {
		shannon_printk(KERN_ERR "%s(): alloc sg failed.\n", __func__);
		return -ENOMEM;
	}
	shannon_sg_init_table(sbio->sg, sbio->sg_count);

	sbio->bio_size = get_bi_size(lbio);
	sbio->start_sector = get_bi_sector(lbio);

	sbio->first_size = logicb_size - ((sbio->start_sector << 9) & (logicb_size - 1));
	sbio->first_size = sbio->first_size % logicb_size;
	sbio->first_size = min(sbio->bio_size, sbio->first_size);


	remained_size = sbio->first_size ? sbio->first_size : logicb_size;

	sbio->has_hole = 0;
	sbio->used_sg_count = 0;
	bio_for_each_segment(bvec, bio, iter) {
		/* all segments' bv_offset have to be 0, except the first one. */
		if ((iter.bi_idx != bio->bi_iter.bi_idx) && (bvec.bv_offset != 0))
			sbio->has_hole = 1;
		/* all segments have to end at 4096, except the last one. */
		if ((iter.bi_idx != (sbio->segments - 1)) && ((bvec.bv_offset + bvec.bv_len) != 4096))
			sbio->has_hole = 1;

		offset = 0; /* the offset start from bvec->bv_offset. */
		while (offset < bvec.bv_len) {
			if ((bvec.bv_len - offset) < remained_size) {
				map_size = bvec.bv_len - offset;
				undone = 1;
			} else {
				map_size = remained_size;
				undone = 0;
			}
			remained_size -= map_size;
			if (remained_size == 0)
				remained_size = logicb_size;
			sg = sg ? shannon_sg_next(sg) : sbio->sg;
			shannon_sg_set_page(sg, bvec.bv_page, map_size, bvec.bv_offset + offset);
			sbio->used_sg_count++;

			offset += map_size;
		}
	}
	shannon_sg_mark_end(sg);

	return 0;
}
#else
int shannon_convert_bio(struct shannon_dev *sdev, struct shannon_bio *sbio, shannon_bio_t *lbio)
{
	shannon_sg_list_t *sg = NULL;
	struct bio *bio = (struct bio *)lbio;
	struct bio_vec *bvec;
	int i, offset, remained_size, map_size = 0, undone = 0;
	unsigned int logicb_size = get_logicb_size(sdev);

	sbio->segments = shannon_bio_segments(lbio);
	sbio->sg_count = 2 * sbio->segments + 1;
	sbio->sg = shannon_sg_alloc(sbio->sg_count, GFP_SHANNON);
	if (sbio->sg == NULL) {
		shannon_printk(KERN_ERR "%s(): alloc sg failed.\n", __func__);
		return -ENOMEM;
	}
	shannon_sg_init_table(sbio->sg, sbio->sg_count);

	sbio->bio_size = get_bi_size(lbio);
	sbio->start_sector = get_bi_sector(lbio);

	sbio->first_size = logicb_size - ((sbio->start_sector << 9) & (logicb_size - 1));
	sbio->first_size = sbio->first_size % logicb_size;
	sbio->first_size = min(sbio->bio_size, sbio->first_size);


	remained_size = sbio->first_size ? sbio->first_size : logicb_size;

	sbio->has_hole = 0;
	sbio->used_sg_count = 0;
	bio_for_each_segment(bvec, bio, i) {
		/* all segments' bv_offset have to be 0, except the first one. */
		if ((i != bio->bi_idx) && (bvec->bv_offset != 0))
			sbio->has_hole = 1;
		/* all segments have to end at 4096, except the last one. */
		if ((i != (sbio->segments - 1)) && ((bvec->bv_offset + bvec->bv_len) != 4096))
			sbio->has_hole = 1;

		offset = 0; /* the offset start from bvec->bv_offset. */
		while (offset < bvec->bv_len) {
			if ((bvec->bv_len - offset) < remained_size) {
				map_size = bvec->bv_len - offset;
				undone = 1;
			} else {
				map_size = remained_size;
				undone = 0;
			}
			remained_size -= map_size;
			if (remained_size == 0)
				remained_size = logicb_size;
			sg = sg ? shannon_sg_next(sg) : sbio->sg;
			shannon_sg_set_page(sg, bvec->bv_page, map_size, bvec->bv_offset + offset);
			sbio->used_sg_count++;

			offset += map_size;
		}
	}
	shannon_sg_mark_end(sg);

	return 0;
}
#endif

int shannon_make_request(shannon_request_queue_t *q, shannon_bio_t *bio)
{
	struct shannon_dev *sdev = ((struct request_queue *)q)->queuedata;
	struct shannon_bio *sbio;
	int ret;
	unsigned int logicb_size = get_logicb_size(sdev);
	unsigned int logicb_shift = get_logicb_shift(sdev);

	if (shannon_check_availability(sdev))
	{
		shannon_bio_endio(bio, -EIO);
		return 0;
	}

	if (unlikely(shannon_should_trim_bio(bio))) {
		/* in sectors */
		u64 trim_start = get_bi_sector(bio);
		u64 trim_end = trim_start + (get_bi_size(bio) >> 9);
		trim_start = _ALIGN_UP(trim_start, logicb_size/512);
		trim_end = _ALIGN_DOWN(trim_end, logicb_size/512);
		/* in logicbs */
		trim_start = trim_start >> (logicb_shift - 9);
		trim_end = trim_end >> (logicb_shift - 9);
		shannon_discard(sdev, trim_start, trim_end);
		shannon_bio_endio(bio, 0);
		return 0;
	}

	if (unlikely(get_bi_size(bio) == 0)) {
		shannon_bio_endio(bio, 0);
		return 0;
	}

	if (unlikely(shannon_disk_readonly(sdev)) && (shannon_bio_data_dir(bio) == LINUX_BIO_WRITE)) {
		shannon_bio_endio(bio, -EIO);
		return 0;
	}

	sbio = alloc_sbio(GFP_SHANNON);
	sbio->bio = bio;
	sbio->lreq = NULL;
	if (shannon_bio_data_dir(bio))
		sbio->dma_dir = SHANNON_DMA_TODEVICE;
	else
		sbio->dma_dir = SHANNON_DMA_FROMDEVICE;
	SHANNON_INIT_LIST_HEAD(&sbio->req_list);
	set_sbio_debug_tag(sbio, MAKE_REQUEST_TAG);

	ret = shannon_convert_bio(sdev, sbio, bio);
	if (ret)
		goto free_sbio;

	// skipped request queue and io scheduler, must do disk statistics manually.
	sbio->start_time = get_jiffies();
	shannon_start_io_acct(get_gendisk_from_sdev(sdev), sbio->bio);

	ret = shannon_submit_bio(sdev, sbio);
	if (ret)
		goto free_sg_list;

	return 0;

free_sg_list:
	shannon_end_io_acct(get_gendisk_from_sdev(sdev), sbio->bio, 0);
	if (sbio->sg)
		shannon_sg_free(sbio->sg, sbio->sg_count);
free_sbio:
	free_sbio(sbio);
	if (ret == -ENOMEM) {
		/* will make_request(this_bio) again */
		return -ENOMEM;
	} else {
		shannon_bio_endio(bio, ret);
		return 0;
	}
 }

//  make_request
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,2,0)
static void shannon_make_request_wrapper(struct request_queue *q, struct bio *bio)
{
	shannon_make_request(q, bio);
}
#else
static int shannon_make_request_wrapper(struct request_queue *q, struct bio *bio)
{
	return shannon_make_request(q, bio);
}
#endif

#define LREQ_IO_GOOD	1
#define LREQ_IO_ERROR	0

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25)

static inline void complete_buffers(struct bio *bio, int status)
{
	while (bio) {
		struct bio *xbh = bio->bi_next;

		bio->bi_next = NULL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
		blk_finished_io(bio_sectors(bio));
#endif
		shannon_bio_endio(bio, status ? 0 : -EIO);
		bio = xbh;
	}
}

static void shannon_end_request(shannon_lreq_t *lreq)
{
	struct request *rq = (struct request *)lreq;
	struct request_queue *q = rq->q;
	unsigned long flags;

	complete_buffers(rq->bio, rq->errors);

	if (blk_fs_request(rq)) {
		const int rw = rq_data_dir(rq);
		disk_stat_add(rq->rq_disk, sectors[rw], rq->nr_sectors);
	}

	add_disk_randomness(rq->rq_disk);
	spin_lock_irqsave(q->queue_lock, flags);
	end_that_request_last(rq, rq->errors);
	spin_unlock_irqrestore(q->queue_lock, flags);
}


#else /* LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25) */

static void shannon_end_request(shannon_lreq_t *lreq)
{
	struct request *rq = (struct request *)lreq;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	blk_end_request_all(rq, rq->errors ? 0 : -EIO);
#else
	blk_end_request(rq, rq->errors ? 0 : -EIO, blk_rq_bytes(rq));
#endif
}

#endif /* LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25) */

static void shannon_set_lreq_errors(shannon_lreq_t *lreq, int errors)
{
	struct request *rq = (struct request *)lreq;

	rq->errors = errors;
}

extern void shannon_scsi_end_io_acct(struct shannon_scsi_private *hostdata, struct shannon_bio *sbio, unsigned long duration);
void shannon_complete_fs_io(void *hostdata, shannon_gendisk_t *gd, struct shannon_bio *sbio)
{
	/* A fs sbio is converted from either a bio or a request*/
	if (sbio->bio) {
		// If we skipped request queue and io scheduler, must do disk statistics manually.
		shannon_end_io_acct(gd, sbio->bio, get_jiffies() - sbio->start_time);
		if (likely(sbio->status == 0))
			shannon_bio_endio(sbio->bio, 0);
		else {
			debugs0("Error sectors!, status=0x%x, dma_dir=%d.\n", sbio->status, sbio->dma_dir);
			shannon_bio_endio(sbio->bio, -EIO);
		}
	} else if (sbio->lreq) {
		if (likely(sbio->status == 0))
			shannon_set_lreq_errors(sbio->lreq, LREQ_IO_GOOD);
		else {
			shannon_set_lreq_errors(sbio->lreq, LREQ_IO_ERROR);
			shannon_printk(KERN_ERR "%s(): Error sectors!, status=0x%x.\n", __func__, sbio->status);
		}
		shannon_end_request(sbio->lreq);
	} else if (sbio->scsi_cmnd) {
		shannon_scsi_end_io_acct((struct shannon_scsi_private *)hostdata, sbio, get_jiffies() - sbio->start_time);
		end_scsi_cmnd(sbio, STATUS_CODE_GOOD, NULL);
	} else {
		shannon_printk(KERN_ERR "%s(): BUG! A fs sbio isn't related to a bio or a request!", __func__);
		BUG();
	}
}


static inline sector_t shannon_blk_rq_pos(struct request *rq)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	return blk_rq_pos(rq);
#else
	return rq->hard_sector;
#endif
}



static inline unsigned int shannon_blk_rq_bytes(struct request *rq)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25)
	return blk_rq_bytes(rq);
#else
	if (blk_fs_request(rq))
		return rq->hard_nr_sectors << 9;
	return rq->data_len;
#endif
}

static unsigned int shannon_lreq_segments(shannon_lreq_t *lreq)
{
	struct request *rq = (struct request *)lreq;
	struct bio *bio = NULL;
	unsigned int segments = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 24)
	__rq_for_each_bio(bio, rq)
		segments += shannon_bio_segments(bio);
#else
	rq_for_each_bio(bio, rq)
		segments += shannon_bio_segments(bio);
#endif

	return segments;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)
int shannon_convert_lreq(struct shannon_dev *sdev, struct shannon_bio *sbio, shannon_lreq_t *lreq)
{
	shannon_sg_list_t *sg = NULL;
	struct bio_vec bvec;
	struct request *rq = (struct request *)lreq;
	int i, offset, remained_size, map_size = 0, undone = 0;
	unsigned int logicb_size = get_logicb_size(sdev);
	struct req_iterator iter;

	sbio->segments = shannon_lreq_segments(lreq);
	sbio->sg_count = 2 * sbio->segments + 1;
	sbio->sg = shannon_sg_alloc(sbio->sg_count, GFP_SHANNON);
	if (sbio->sg == NULL) {
		shannon_printk(KERN_ERR "%s(): alloc sg failed.\n", __func__);
		return -ENOMEM;
	}
	shannon_sg_init_table(sbio->sg, sbio->sg_count);

	sbio->bio_size = shannon_blk_rq_bytes(rq);
	sbio->start_sector = shannon_blk_rq_pos(rq);

	sbio->first_size = logicb_size - ((sbio->start_sector << 9) & (logicb_size - 1));
	sbio->first_size = sbio->first_size % logicb_size;
	sbio->first_size = min(sbio->bio_size, sbio->first_size);


	remained_size = sbio->first_size ? sbio->first_size : logicb_size;

	sbio->has_hole = 0;
	sbio->used_sg_count = 0;

	i = 0;
	rq_for_each_segment(bvec, rq, iter)
		{
		/* all segments' bv_offset have to be 0, except the first one. */
		if ((i != 0) && (bvec.bv_offset != 0))
			sbio->has_hole = 1;
		/* all segments have to end at 4096, except the last one. */
		if ((i != (sbio->segments - 1)) && ((bvec.bv_offset + bvec.bv_len) != 4096))
			sbio->has_hole = 1;

		offset = 0; /* the offset start from bvec->bv_offset. */
		while (offset < bvec.bv_len) {
			if ((bvec.bv_len - offset) < remained_size) {
				map_size = bvec.bv_len - offset;
				undone = 1;
			} else {
				map_size = remained_size;
				undone = 0;
			}
			remained_size -= map_size;
			if (remained_size == 0)
				remained_size = logicb_size;
			sg = sg ? shannon_sg_next(sg) : sbio->sg;
			shannon_sg_set_page(sg, bvec.bv_page, map_size, bvec.bv_offset + offset);
			sbio->used_sg_count++;

			offset += map_size;
		}
		i++;
	}

	shannon_sg_mark_end(sg);

	return 0;
}
#else
int shannon_convert_lreq(struct shannon_dev *sdev, struct shannon_bio *sbio, shannon_lreq_t *lreq)
{
	shannon_sg_list_t *sg = NULL;
	struct bio_vec *bvec;
	struct request *rq = (struct request *)lreq;
	int i, offset, remained_size, map_size = 0, undone = 0;
	unsigned int logicb_size = get_logicb_size(sdev);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 24)
	struct req_iterator iter;
#else
	struct bio *bio;
	int j;
#endif

	sbio->segments = shannon_lreq_segments(lreq);
	sbio->sg_count = 2 * sbio->segments + 1;
	sbio->sg = shannon_sg_alloc(sbio->sg_count, GFP_SHANNON);
	if (sbio->sg == NULL) {
		shannon_printk(KERN_ERR "%s(): alloc sg failed.\n", __func__);
		return -ENOMEM;
	}
	shannon_sg_init_table(sbio->sg, sbio->sg_count);

	sbio->bio_size = shannon_blk_rq_bytes(rq);
	sbio->start_sector = shannon_blk_rq_pos(rq);

	sbio->first_size = logicb_size - ((sbio->start_sector << 9) & (logicb_size - 1));
	sbio->first_size = sbio->first_size % logicb_size;
	sbio->first_size = min(sbio->bio_size, sbio->first_size);


	remained_size = sbio->first_size ? sbio->first_size : logicb_size;

	sbio->has_hole = 0;
	sbio->used_sg_count = 0;

	i = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 24)
	rq_for_each_segment(bvec, rq, iter)
#else
	rq_for_each_bio(bio, rq)
		bio_for_each_segment(bvec, bio, j)
#endif
		{
		/* all segments' bv_offset have to be 0, except the first one. */
		if ((i != 0) && (bvec->bv_offset != 0))
			sbio->has_hole = 1;
		/* all segments have to end at 4096, except the last one. */
		if ((i != (sbio->segments - 1)) && ((bvec->bv_offset + bvec->bv_len) != 4096))
			sbio->has_hole = 1;

		offset = 0; /* the offset start from bvec->bv_offset. */
		while (offset < bvec->bv_len) {
			if ((bvec->bv_len - offset) < remained_size) {
				map_size = bvec->bv_len - offset;
				undone = 1;
			} else {
				map_size = remained_size;
				undone = 0;
			}
			remained_size -= map_size;
			if (remained_size == 0)
				remained_size = logicb_size;
			sg = sg ? shannon_sg_next(sg) : sbio->sg;
			shannon_sg_set_page(sg, bvec->bv_page, map_size, bvec->bv_offset + offset);
			sbio->used_sg_count++;

			offset += map_size;
		}
		i++;
	}

	shannon_sg_mark_end(sg);

	return 0;
}
#endif

int shannon_disk_xfer_request(struct shannon_dev *sdev, struct request *rq)
{
	int ret;
	struct shannon_bio *sbio = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
	unsigned int logicb_size = get_logicb_size(sdev);
	unsigned int logicb_shift = get_logicb_shift(sdev);
#endif


	if (shannon_check_availability(sdev))
	{
		rq->errors = LREQ_IO_ERROR;
		shannon_end_request(rq);
		return 0;
	}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2, 6, 19)
	if (!blk_fs_request(rq))
#else
	if (rq->cmd_type != REQ_TYPE_FS)
#endif
	{
		debugs1("skip non-fs request.\n");
		rq->errors = LREQ_IO_ERROR;
		shannon_end_request(rq);
		return 0;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28)
	if (unlikely(rq->cmd_flags & REQ_DISCARD)) {
		/* in sectors */
		u64 trim_start = shannon_blk_rq_pos(rq);
		u64 trim_end = trim_start + (shannon_blk_rq_bytes(rq) >> 9);
		trim_start = _ALIGN_UP(trim_start, logicb_size/512);
		trim_end = _ALIGN_DOWN(trim_end, logicb_size/512);
		/* in logicbs */
		trim_start = trim_start >> (logicb_shift - 9);
		trim_end = trim_end >> (logicb_shift - 9);
		shannon_discard(sdev, trim_start, trim_end);
		rq->errors = LREQ_IO_GOOD;
		shannon_end_request(rq);
		return 0;
	}
#endif

	if (unlikely(shannon_blk_rq_bytes(rq) == 0)) {
		rq->errors = LREQ_IO_GOOD;
		shannon_end_request(rq);
		return 0;
	}

	if (unlikely(shannon_disk_readonly(sdev)) && (rq_data_dir(rq) == LREQ_WRITE)) {
		rq->errors = LREQ_IO_ERROR;
		shannon_end_request(rq);
		return 0;
	}

	sbio = alloc_sbio(GFP_SHANNON);
	sbio->bio = NULL;
	sbio->lreq = rq;
	if (rq_data_dir(rq))
		sbio->dma_dir = SHANNON_DMA_TODEVICE;
	else
		sbio->dma_dir = SHANNON_DMA_FROMDEVICE;
	SHANNON_INIT_LIST_HEAD(&sbio->req_list);
	set_sbio_debug_tag(sbio, LINUX_REQ_TAG);

	ret = shannon_convert_lreq(sdev, sbio, rq);
	if (ret)
		goto free_sbio;

	ret = shannon_submit_bio(sdev, sbio);
	if (ret)
		goto free_sg_list;

	return 0;

free_sg_list:
	if (sbio->sg)
		shannon_sg_free(sbio->sg, sbio->sg_count);
free_sbio:
	free_sbio(sbio);
	if (ret == -ENOMEM) {
		/* will enqueue this request again */
		return -ENOMEM;
	} else {
		rq->errors = LREQ_IO_ERROR;
		shannon_end_request(rq);
		return 0;
	}
	return 0;
}

void shannon_disk_request(struct request_queue *q)
{
	struct shannon_dev *sdev = q->queuedata;
	struct request *rq;
	int ret;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	while ((rq = blk_peek_request(q))) {
		blk_start_request(rq);
#else
	while ((rq = elv_next_request(q))) {
		blkdev_dequeue_request(rq);
#endif
		spin_unlock_irq(q->queue_lock);

		ret = shannon_disk_xfer_request(sdev, rq);
		if (ret == -ENOMEM) {
			spin_lock_irq(q->queue_lock);
			blk_requeue_request(q, rq);
			spin_unlock_irq(q->queue_lock);
		}
		spin_lock_irq(q->queue_lock);
	}
}

static int shannon_elevator_change(struct request_queue *q, char *name)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 36)
	return elevator_change(q, name);
#else
	elevator_exit(q->elevator);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
	q->elevator = NULL;
#endif
	return elevator_init(q, name);
#endif
}

static shannon_request_queue_t *shannon_init_queue(struct shannon_dev *sdev, shannon_spinlock_t *lock)
{
	struct request_queue *queue = NULL;
	static char elevator_name[] = "noop";

	shannon_spin_lock_init(lock);
	queue = blk_init_queue((request_fn_proc *)shannon_disk_request,
		(spinlock_t *)lock);

	if (queue) {
		if (shannon_elevator_change(queue, elevator_name)) {
			shannon_printk(KERN_ERR "%s(): Error: Failed to initialize noop io scheduler.\n", __func__);
			blk_cleanup_queue(queue);
			queue = NULL;
		} else {
			shannon_printk(KERN_ERR "%s(): using noop io scheduler.\n", __func__);
			queue->queuedata = sdev;
		}
	}

	return queue;
}

static shannon_request_queue_t *shannon_alloc_queue(struct shannon_dev *sdev)
{
	struct request_queue *queue = NULL;

	queue = blk_alloc_queue(GFP_SHANNON);
	if (queue) {
		blk_queue_make_request(queue, shannon_make_request_wrapper);
		queue->queuedata = sdev;
	}

	return queue;
}

shannon_request_queue_t *shannon_create_blkqueue(struct shannon_dev *sdev, shannon_spinlock_t *lock)
{
	if (shannon_use_iosched)
		return shannon_init_queue(sdev, lock);
	else
		return shannon_alloc_queue(sdev);
}
