#include "shannon_workqueue.h"
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/workqueue.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20)
struct __delayed_work {
	struct work_struct work;
};
#endif

void shannon_init_work(struct shannon_work_struct *work, shannon_work_func_t func)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	INIT_WORK((struct work_struct *)work, (work_func_t)func);
#else
	INIT_WORK((struct work_struct *)work, (void *)func, work);
#endif
}

void shannon_init_delayed_work(struct shannon_delayed_work *work, shannon_work_func_t func)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	INIT_DELAYED_WORK((struct delayed_work *)work, (work_func_t)func);
#else
	INIT_WORK((struct work_struct *)work, (void *)func, work);
#endif
}

struct shannon_delayed_work *get_delayed_work(struct shannon_work_struct *work)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	struct delayed_work *delayed_work = container_of((struct work_struct *)work, struct delayed_work, work);
	return (struct shannon_delayed_work *)delayed_work;
#else
	return (struct shannon_delayed_work *)work;
#endif

}

int shannon_queue_work(shannon_workqueue_struct_t *wq, struct shannon_work_struct *work)
{
	return queue_work((struct workqueue_struct *)wq, (struct work_struct *)work);
}

shannon_workqueue_struct_t *shannon_create_singlethread_workqueue(const char *name)
{
	return create_singlethread_workqueue(name);
}

shannon_workqueue_struct_t *shannon_create_workqueue(const char *name)
{
	return create_workqueue(name);
}

void shannon_destroy_workqueue(shannon_workqueue_struct_t *wq)
{
	destroy_workqueue((struct workqueue_struct *)wq);
}

void shannon_flush_workqueue(shannon_workqueue_struct_t *wq)
{
	flush_workqueue((struct workqueue_struct *)wq);
}

void shannon_cancel_delayed_work(struct shannon_delayed_work *work)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	cancel_delayed_work((struct delayed_work *)work);
#else
	cancel_delayed_work((struct work_struct *)work);
#endif
}


int shannon_queue_delayed_work(shannon_workqueue_struct_t *wq, struct shannon_delayed_work *work, unsigned long delay)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	return queue_delayed_work((struct workqueue_struct *)wq, (struct delayed_work *)work, delay);
#else
	return queue_delayed_work((struct workqueue_struct *)wq, (struct work_struct *)work, delay);
#endif
}

int shannon_schedule_delayed_work(struct shannon_delayed_work *work, unsigned long delay)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	return schedule_delayed_work((struct delayed_work *)work, delay);
#else
	return schedule_delayed_work((struct work_struct *)work, delay);
#endif
}

int shannon_schedule_work(struct shannon_work_struct *work)
{
	return schedule_work((struct work_struct *)work);
}

void shannon_work_clear_pending(struct shannon_work_struct *work)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20)
	clear_bit(0, &((struct work_struct *)work)->pending);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 22)
	work_release((struct work_struct *)work);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(3, 16, 0)
	work_clear_pending((struct work_struct *)work);
#else
	clear_bit(WORK_STRUCT_PENDING_BIT, work_data_bits((struct work_struct *)work));
#endif
}


int __shannon_cancel_delayed_work(struct shannon_delayed_work *work)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 15, 0)
	int ret;

	ret = del_timer(&((struct delayed_work *)work)->timer);
	if (ret)
		shannon_work_clear_pending((struct shannon_work_struct *)(&((struct delayed_work *)work)->work));
	return ret;
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 31)
	return __cancel_delayed_work((struct delayed_work *)work);
#else
	int ret;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 20)
	ret = del_timer(&((struct delayed_work *)work)->timer);
	if (ret)
		shannon_work_clear_pending((struct shannon_work_struct *)(&((struct delayed_work *)work)->work));
#else
	ret = del_timer(&(((struct __delayed_work *)work)->work.timer));
	if (ret)
		shannon_work_clear_pending((struct shannon_work_struct *)(&((struct __delayed_work *)work)->work));
#endif
	return ret;
#endif
}
